from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key' 

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='#@_royal5566',
        database='new_project'
    )

# Welcome Page
@app.route('/')
def welcome():
    return render_template('welcome.html')

# New admin signup/register route
@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get('name')  
        email = request.form.get('email') 
        password = request.form.get('password')  
        confirm = request.form.get('confirm_password') 

        if password != confirm:  
            flash("Passwords do not match. Please try again.", 'error')
            return redirect(url_for('register'))

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('INSERT INTO radmin (Name, Email, Password, Confirm) VALUES (%s, %s, %s, %s)', 
                       (name, email, password, confirm))
        conn.commit()  
        cursor.close()
        conn.close()

        flash("Welcome, New Admin! Registration Successful.", 'success') 
        return redirect(url_for('login')) 
    return render_template('register.html')

# Admin login route
@app.route('/login', methods=["POST", "GET"])
def login():
    if request.method == "POST":
        email = request.form.get('email')  
        password = request.form.get('password')

        if email and password:  
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)  

            # Verify email and password
            cursor.execute('SELECT * FROM radmin WHERE Email = %s AND Password = %s', (email, password))
            admin = cursor.fetchone()
            conn.close()
            
            if admin: 
                flash("Login successful!", "success")
                return redirect(url_for('dashboard'))  
            else: 
                flash("Invalid email or password!", "error")
                return redirect(url_for('login')) 
        else:
            flash("Please fill in both fields.", "error")
            return redirect(url_for('login')) 

    return render_template('login.html')

# Admin Dashboard 
@app.route('/dashboard')
def dashboard():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM bookings")
    total_booking = cursor.fetchone()[0] 

    cursor.execute("SELECT COUNT(*) FROM rooms")
    total_rooms = cursor.fetchone()[0] 

    current_time = datetime.now().strftime("%H:%M:%S")

    conn.close()

    return render_template('dashboard.html', 
                           total_booking=total_booking, 
                           current_time=current_time,
                           total_rooms=total_rooms
    )

# Customer registration for booking info
@app.route('/rcustomer', methods=["GET", "POST"])
def rcustomer():
    if request.method == "POST":
        try:
            name = request.form['name']
            email = request.form['email']
            address = request.form['address']
            city = request.form['city']
            proofid = request.form['proofid']
            mobile = request.form['mobile']
            nationality = request.form['nationality']
            pincode = request.form['pincode']
            noofguests = request.form['noofguests']

            if not (name and email and address):
                flash("Name, email, and address are required!", "error")
                return redirect(url_for('rcustomer'))

            conn = get_db_connection()
            cursor = conn.cursor()

            query = """
                INSERT INTO rcustomer 
                (name, email, address, city, proofid, mobile, nationality, pincode, noofguests)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = (name, email, address, city, proofid, mobile, nationality, pincode, noofguests)
            cursor.execute(query, values)

            conn.commit()
            flash("Welcome! Registration Successful.", 'success')

        except Exception as e:
            print(f"Database Error: {e}")  
            flash(f"An error occurred: {e}", 'danger')

        finally:
            cursor.close()
            conn.close()

    return render_template('rcustomer.html')

# Booking form route for room booking
@app.route('/booking', methods=['GET', 'POST'])
def booking():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Handle form submission
    if request.method == "POST":
        booking_id = request.form['id']
        name = request.form['name']
        email = request.form['email']
        mobile = request.form['mobile']
        checkin = request.form['checkin']
        checkout = request.form['checkout']
        nationality = request.form['nationality']
        booking_date = request.form['bookingdate']
        pincode = request.form['pincode']
        proof_id = request.form['proofid']
        no_of_guests = request.form['noofguests']
        room_type = request.form['room_type']
        total_price = request.form['total_price']
        status = request.form['status']
        room_number = request.form['room_number']

        try:
            # Insert booking details
            insert_query = """
            INSERT INTO bookings (booking_id, name, email, mobile, checkin_date, checkout_date, nationality, 
                                  booking_date, pincode, proof_id, no_of_guests, room_type, 
                                  total_price, status, room_number)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = (booking_id, name, email, mobile, checkin, checkout, nationality, booking_date,
                      pincode, proof_id, no_of_guests, room_type, total_price, status, room_number)
            cursor.execute(insert_query, values)

            # Update the room status to 'Booked'
            update_query = "UPDATE rooms SET status = %s WHERE room_number = %s"
            cursor.execute(update_query, ("Booked", room_number))

            conn.commit()
            flash("Booking successful!", "success")
        except Exception as e:
            conn.rollback()
            flash(f"An error occurred: {e}", "danger")
        finally:
            cursor.close()
            conn.close()

        return redirect('/view_bookings')

    # Fetch available rooms based on room type if it's a GET request
    if request.method == "GET":
        room_type = request.args.get('room_type')  # Room type passed via query parameter

        if room_type:
            cursor.execute("SELECT room_number, price FROM rooms WHERE status = 'Available' AND room_type = %s", (room_type,))
        else:
            cursor.execute("SELECT room_number FROM rooms WHERE status = 'Available'")

        available_rooms = cursor.fetchall()
        cursor.close()
        conn.close()

        return render_template('booking.html', available_rooms=available_rooms)

@app.route('/view_bookings')
def view_bookings():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute('SELECT * FROM bookings')
    bookings = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('view_bookings.html', bookings=bookings)

# Room Deletion Route
@app.route('/deleteroom/<int:room_number>', methods=['POST'])
def deleteroom(room_number):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("DELETE FROM rooms WHERE room_number = %s", (room_number,))
        conn.commit()
        flash("Room deleted successfully!", "success")
    except Exception as e:
        flash(f"Error deleting room: {e}", "danger")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('roomhistory'))

# Booking Deletion Route
@app.route('/deletebooking/<int:booking_id>', methods=['POST'])
def deletebooking(booking_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT room_number FROM bookings WHERE booking_id = %s", (booking_id,))
        room_number = cursor.fetchone()
        
        if room_number:
            room_number = room_number[0]
            
            # Delete the booking
            cursor.execute("DELETE FROM bookings WHERE booking_id = %s", (booking_id,))
            
            # Update the room status to 'available'
            cursor.execute("UPDATE rooms SET status = 'Available' WHERE room_number = %s", (room_number,))
            
            conn.commit()
            flash("Booking deleted and room marked as available!", "success")
        else:
            flash("Booking not found!", "danger")
    except Exception as e:
        flash(f"Error deleting booking: {e}", "danger")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('view_bookings'))
#add rooms
@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == "POST":
        room_number = request.form['room_number']
        status = request.form['status']
        room_type = request.form['room_type']
        price = request.form['price']

        # Establish database connection
        conn = get_db_connection()
        cursor = conn.cursor()

        # Prepare SQL query for inserting data into the rooms table
        sql = """INSERT INTO rooms (room_number, status, room_type, price) 
                 VALUES (%s, %s, %s, %s)"""
        val = (room_number, status, room_type, price)

        # Debugging: Print SQL query and its values to check before execution
        print("Executing SQL query:", sql)
        print("With values:", val)

        try:
            # Execute the query
            cursor.execute(sql, val)
            conn.commit()
            
            # Flash a success message
            flash("Room added successfully", "success")
            
            # Redirect to the same page after successful insertion
            return redirect(url_for('add'))

        except Exception as e:
            # Log the error
            print("Error occurred:", e)  # Log the exception message
            flash(f"An error occurred while adding the room: {e}", "danger")

        finally:
            # Close the cursor and connection to the database
            cursor.close()
            conn.close()

    # Render the add room form page
    return render_template('add1room.html')
# Room History View
@app.route('/roomhistory')
def roomhistory():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT room_number, status,room_type,price FROM rooms")
    rooms = cursor.fetchall() or []

    cursor.close()
    conn.close()

    if not rooms:
        flash("No room records found.", "warning")

    return render_template('roomaddedhistory.html', rooms=rooms)

# Logout Route
@app.route('/logout')  
def logout():
    session.clear()  # Clear the session
    flash("You have been logged out.", "info")
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
